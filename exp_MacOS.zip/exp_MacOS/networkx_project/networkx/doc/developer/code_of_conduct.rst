.. include:: ../../CODE_OF_CONDUCT.rst

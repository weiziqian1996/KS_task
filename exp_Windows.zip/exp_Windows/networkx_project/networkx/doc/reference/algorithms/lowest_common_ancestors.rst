**********************
Lowest Common Ancestor
**********************

.. automodule:: networkx.algorithms.lowest_common_ancestors
.. autosummary::
   :toctree: generated/

   all_pairs_lowest_common_ancestor
   tree_all_pairs_lowest_common_ancestor
   lowest_common_ancestor

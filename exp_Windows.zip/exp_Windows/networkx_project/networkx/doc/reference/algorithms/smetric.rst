********
s metric
********

.. automodule:: networkx.algorithms.smetric
.. autosummary::
   :toctree: generated/

   s_metric

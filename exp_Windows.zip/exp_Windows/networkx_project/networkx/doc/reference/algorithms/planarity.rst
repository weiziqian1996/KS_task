*********
Planarity
*********

.. automodule:: networkx.algorithms.planarity
.. autosummary::
   :toctree: generated/

   check_planarity
.. autoclass:: PlanarEmbedding
   :members:
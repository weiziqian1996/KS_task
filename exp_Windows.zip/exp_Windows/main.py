#!/usr/bin/env python
# -*- coding: utf-8 -*-

from settings import *
from components import *
from functions import *
from cmap_task import *
from writing_task import *
from reading_task import *
from instruction_page import *

for i in [1, 2, 3, 'r', 4, 5, 6, 'c']:
    if type(i) == int:
        run_instruction_page(i)
    elif i == 'r':
        run_reading_task()
    elif i == 'c':
        run_cmap_task()
    elif i == 'w':
        run_writing_task()
    show_interval(wait_secs=0.5)

win.close()
print('不要管上面那些WARNING，如果你看到这行文字，说明程序已经顺利运行并结束了')

*********
Dominance
*********

.. automodule:: networkx.algorithms.dominance
.. autosummary::
   :toctree: generated/

   immediate_dominators
   dominance_frontiers

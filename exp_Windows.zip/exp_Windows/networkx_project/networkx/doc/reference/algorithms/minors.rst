******
Minors
******

.. automodule:: networkx.algorithms.minors
.. autosummary::
   :toctree: generated/

   contracted_edge
   contracted_nodes
   identified_nodes
   equivalence_classes
   quotient_graph
